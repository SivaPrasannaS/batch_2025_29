package com.examly.springapp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.context.ConfigurableApplicationContext;

public class ContactBookAssessmentTests {

    private static final String BASE = "com.examly.springapp";
    private static final String MAIN_CLASS = BASE + ".SpringappApplication";
    private static final String INFO = BASE + ".model.OwnerProfile";
    private static final String CONFIG = BASE + ".config.ContactConfig";
    private static final String STORE = BASE + ".service.ContactStore";
    private static final String SERVICE = BASE + ".service.ContactService";

    private static final String EXPECTED_OUTPUT = String.join("\n",
            "Meena's Contacts",
            "Anu - 9123456789",
            "Deepa - 9988776655",
            "Ravi - 9876543210",
            "Total contacts: 3");

    // ---------------- Helper methods ----------------
    // Student classes are used only through reflection, so this file
    // always compiles even if a class or method is missing.

    private Class<?> requireClass(String className) {
        Class<?> type = null;
        try {
            type = Class.forName(className);
        } catch (Throwable t) {
            type = null;
        }
        assertNotNull(type, "Class not found: " + className);
        return type;
    }

    private ConfigurableApplicationContext requireContext() {
        ConfigurableApplicationContext context = null;
        try {
            SpringApplication application = new SpringApplication(Class.forName(MAIN_CLASS));
            application.setBannerMode(Banner.Mode.OFF);
            application.setLogStartupInfo(false);
            application.setWebApplicationType(WebApplicationType.NONE);
            context = application.run();
        } catch (Throwable t) {
            context = null;
        }
        assertNotNull(context, "Spring application could not start. Check annotations and bean wiring.");
        return context;
    }

    private void closeContext(ConfigurableApplicationContext context) {
        if (context != null) {
            try {
                context.close();
            } catch (Throwable ignored) {
                // nothing to do
            }
        }
    }

    private Object requireBean(ConfigurableApplicationContext context, String className) {
        Class<?> type = requireClass(className);
        Object bean = null;
        try {
            bean = context.getBean(type);
        } catch (Throwable t) {
            bean = null;
        }
        assertNotNull(bean, "No Spring bean found for " + type.getSimpleName());
        return bean;
    }

    private Object call(Object target, String methodName, Object... args) throws Exception {
        assertNotNull(target, "Cannot call " + methodName + " on null");
        for (Method method : target.getClass().getMethods()) {
            if (method.getName().equals(methodName) && method.getParameterCount() == args.length) {
                try {
                    return method.invoke(target, args);
                } catch (IllegalArgumentException e) {
                    continue;
                } catch (InvocationTargetException e) {
                    throw new Exception(methodName + " threw " + e.getCause(), e.getCause());
                }
            }
        }
        throw new NoSuchMethodException("Method not found: " + methodName + " with " + args.length + " parameter(s)");
    }

    private Object create(String className, Object... args) throws Exception {
        Class<?> type = requireClass(className);
        for (Constructor<?> constructor : type.getConstructors()) {
            if (constructor.getParameterCount() == args.length) {
                try {
                    return constructor.newInstance(args);
                } catch (IllegalArgumentException e) {
                    continue;
                } catch (InvocationTargetException e) {
                    throw new Exception(type.getSimpleName() + " constructor threw " + e.getCause(), e.getCause());
                }
            }
        }
        throw new NoSuchMethodException("No public constructor with " + args.length + " parameter(s) in " + type.getSimpleName());
    }

    private void requireConstructor(Class<?> type, Class<?>... parameterTypes) {
        try {
            type.getConstructor(parameterTypes);
        } catch (Throwable t) {
            fail(type.getSimpleName() + " must have a public constructor with parameters " + Arrays.toString(parameterTypes));
        }
    }

    private void requireMethod(Class<?> type, String methodName, Class<?>... parameterTypes) {
        try {
            type.getMethod(methodName, parameterTypes);
        } catch (Throwable t) {
            fail(type.getSimpleName() + " must have a public method " + methodName + " with parameters " + Arrays.toString(parameterTypes));
        }
    }

    private int asInt(Object value) {
        assertTrue(value instanceof Number, "Expected a number but got " + value);
        return ((Number) value).intValue();
    }

    private List<?> asList(Object value) {
        assertNotNull(value, "Expected a List but got null");
        assertTrue(value instanceof List, "Expected a List but got " + value.getClass().getSimpleName());
        return (List<?>) value;
    }

    private List<String> values(Object list, String getterName) throws Exception {
        List<String> result = new ArrayList<>();
        for (Object item : asList(list)) {
            result.add(String.valueOf(call(item, getterName)));
        }
        return result;
    }

    private Object fieldOfType(Object target, Class<?> fieldType) throws Exception {
        for (Field field : target.getClass().getDeclaredFields()) {
            if (fieldType.isAssignableFrom(field.getType())) {
                field.setAccessible(true);
                return field.get(target);
            }
        }
        return null;
    }

    private void checkComponentBean(String className) {
        ConfigurableApplicationContext context = null;
        try {
            context = requireContext();
            Class<?> type = requireClass(className);
            String[] names = context.getBeanNamesForType(type);
            assertEquals(1, names.length, type.getSimpleName() + " must be registered once as a Spring bean");
            BeanDefinition definition = context.getBeanFactory().getBeanDefinition(names[0]);
            assertNull(definition.getFactoryMethodName(), type.getSimpleName() + " must be found by component scanning, not created by a @Bean method");
            assertSame(context.getBean(type), context.getBean(type), type.getSimpleName() + " must be a singleton");
        } catch (Exception e) {
            fail("Component check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    private void checkBeanMethod(String beanClassName, String methodName, String configClassName) {
        ConfigurableApplicationContext context = null;
        try {
            context = requireContext();
            Class<?> beanClass = requireClass(beanClassName);
            String[] names = context.getBeanNamesForType(beanClass);
            assertEquals(1, names.length, "Exactly one " + beanClass.getSimpleName() + " bean must exist");
            BeanDefinition definition = context.getBeanFactory().getBeanDefinition(names[0]);
            assertEquals(methodName, definition.getFactoryMethodName(), beanClass.getSimpleName() + " must be created by a @Bean method named " + methodName);
            assertNotNull(definition.getFactoryBeanName(), "The @Bean method must be inside a configuration class");
            Object configBean = context.getBean(definition.getFactoryBeanName());
            assertTrue(requireClass(configClassName).isInstance(configBean), "The @Bean method must be inside " + configClassName);
            assertSame(context.getBean(beanClass), call(configBean, methodName), "The configuration class must use @Configuration so the same bean is returned");
        } catch (Exception e) {
            fail("Configuration check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    private void checkPrintOutput(String serviceClassName, String loadMethod, String printMethod, String expected) {
        ConfigurableApplicationContext context = null;
        PrintStream originalOut = System.out;
        try {
            context = requireContext();
            Object service = requireBean(context, serviceClassName);
            call(service, loadMethod);
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            try {
                System.setOut(new PrintStream(buffer, true, "UTF-8"));
                call(service, printMethod);
            } finally {
                System.setOut(originalOut);
            }
            String actual = buffer.toString("UTF-8").replace("\r\n", "\n").replaceAll("\\n+$", "");
            assertEquals(expected, actual, "Terminal output does not match the expected output");
        } catch (Exception e) {
            System.setOut(originalOut);
            fail("Output check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    // ---------------- Test cases ----------------

    @Test
    public void testOwnerProfileBeanHasCorrectName() {
        ConfigurableApplicationContext context = null;
        try {
            context = requireContext();
            Object owner = requireBean(context, INFO);
            assertEquals("Meena", call(owner, "getOwnerName"), "Owner name is incorrect");
        } catch (Exception e) {
            fail("OwnerProfile bean check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    @Test
    public void testOwnerProfileCreatedByBeanMethodInConfiguration() {
        checkBeanMethod(INFO, "ownerProfile", CONFIG);
    }

    @Test
    public void testContactStoreIsComponentBean() {
        checkComponentBean(STORE);
    }

    @Test
    public void testContactServiceIsComponentBean() {
        checkComponentBean(SERVICE);
    }

    @Test
    public void testContactServiceUsesSetterInjection() {
        ConfigurableApplicationContext context = null;
        try {
            Class<?> serviceClass = requireClass(SERVICE);
            requireConstructor(serviceClass);
            requireMethod(serviceClass, "setContactStore", requireClass(STORE));
            requireMethod(serviceClass, "setOwnerProfile", requireClass(INFO));
            context = requireContext();
            Object service = requireBean(context, SERVICE);
            assertSame(requireBean(context, STORE), fieldOfType(service, requireClass(STORE)), "ContactService must receive the ContactStore bean from Spring");
            assertSame(requireBean(context, INFO), fieldOfType(service, requireClass(INFO)), "ContactService must receive the OwnerProfile bean from Spring");
        } catch (Exception e) {
            fail("Setter injection check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    @Test
    public void testAddContactKeepsNamesSorted() {
        try {
            Object store = create(STORE);
            assertEquals(Boolean.TRUE, call(store, "addContact", "Zara", "9000000001"), "A valid contact must be accepted");
            assertEquals(Boolean.TRUE, call(store, "addContact", "Bala", "9000000002"), "A valid contact must be accepted");
            assertEquals(Boolean.TRUE, call(store, "addContact", "Mohan", "9000000003"), "A valid contact must be accepted");
            assertEquals(Arrays.asList("Bala", "Mohan", "Zara"), asList(call(store, "getContactNames")), "Contact names must be in alphabetical order");
            assertEquals("9000000003", call(store, "getPhone", "Mohan"), "getPhone returned the wrong number");
            assertNull(call(store, "getPhone", "Unknown"), "getPhone must return null for an unknown name");
        } catch (Exception e) {
            fail("Sorted contacts check failed: " + e);
        }
    }

    @Test
    public void testAddContactRejectsInvalidData() {
        try {
            Object store = create(STORE);
            call(store, "addContact", "Bala", "9000000002");
            assertEquals(Boolean.FALSE, call(store, "addContact", "Arjun", "98765"), "A short phone number must be rejected");
            assertEquals(Boolean.FALSE, call(store, "addContact", "Arjun", "98765abcde"), "A phone number with letters must be rejected");
            assertEquals(Boolean.FALSE, call(store, "addContact", "Arjun", null), "A null phone number must be rejected");
            assertEquals(Boolean.FALSE, call(store, "addContact", "  ", "9000000004"), "A blank name must be rejected");
            assertEquals(Boolean.FALSE, call(store, "addContact", "Bala", "9111111111"), "A duplicate name must be rejected");
            assertEquals(1, asInt(call(store, "getContactCount")), "Invalid contacts must not be stored");
            assertEquals("9000000002", call(store, "getPhone", "Bala"), "The original number must not change");
        } catch (Exception e) {
            fail("Invalid contact check failed: " + e);
        }
    }

    @Test
    public void testDeleteContactRemovesEntry() {
        try {
            Object store = create(STORE);
            call(store, "addContact", "Bala", "9000000002");
            call(store, "addContact", "Zara", "9000000001");
            assertEquals(Boolean.TRUE, call(store, "deleteContact", "Bala"), "Deleting an existing contact must return true");
            assertEquals(Boolean.FALSE, call(store, "deleteContact", "Bala"), "Deleting a missing contact must return false");
            assertEquals(Arrays.asList("Zara"), asList(call(store, "getContactNames")), "Remaining contacts are incorrect");
        } catch (Exception e) {
            fail("Delete contact check failed: " + e);
        }
    }

    @Test
    public void testLoadContactsSkipsInvalidPhone() {
        ConfigurableApplicationContext context = null;
        try {
            context = requireContext();
            Object service = requireBean(context, SERVICE);
            Object store = requireBean(context, STORE);
            call(service, "loadContacts");
            assertEquals(3, asInt(call(store, "getContactCount")), "loadContacts must store 3 contacts");
            assertEquals(Arrays.asList("Anu", "Deepa", "Ravi"), asList(call(store, "getContactNames")), "Contacts loaded are incorrect or not sorted");
            assertNull(call(store, "getPhone", "Kavin"), "Kavin has an invalid number and must not be stored");
        } catch (Exception e) {
            fail("Load contacts check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    @Test
    public void testPrintContactsShowsExactOutput() {
        checkPrintOutput(SERVICE, "loadContacts", "printContacts", EXPECTED_OUTPUT);
    }
}
