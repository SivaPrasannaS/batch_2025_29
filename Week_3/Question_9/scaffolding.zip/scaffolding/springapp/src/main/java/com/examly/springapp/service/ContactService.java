package com.examly.springapp.service;

public class ContactService {

}
