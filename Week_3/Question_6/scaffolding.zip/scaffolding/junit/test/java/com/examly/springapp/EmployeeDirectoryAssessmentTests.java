package com.examly.springapp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.context.ConfigurableApplicationContext;

public class EmployeeDirectoryAssessmentTests {

    private static final String BASE = "com.examly.springapp";
    private static final String MAIN_CLASS = BASE + ".SpringappApplication";
    private static final String EMPLOYEE = BASE + ".model.Employee";
    private static final String INFO = BASE + ".model.CompanyInfo";
    private static final String CONFIG = BASE + ".config.CompanyConfig";
    private static final String STORE = BASE + ".service.EmployeeDirectory";
    private static final String SERVICE = BASE + ".service.DirectoryService";

    private static final String EXPECTED_OUTPUT = String.join("\n",
            "TechNova Solutions - Employee Directory",
            "101 - Anitha - Development",
            "102 - Bharath - Testing",
            "103 - Charan - Development",
            "Development team size: 2");

    // ---------------- Helper methods ----------------
    // Student classes are used only through reflection, so this file
    // always compiles even if a class or method is missing.

    private Class<?> requireClass(String className) {
        Class<?> type = null;
        try {
            type = Class.forName(className);
        } catch (Throwable t) {
            type = null;
        }
        assertNotNull(type, "Class not found: " + className);
        return type;
    }

    private ConfigurableApplicationContext requireContext() {
        ConfigurableApplicationContext context = null;
        try {
            SpringApplication application = new SpringApplication(Class.forName(MAIN_CLASS));
            application.setBannerMode(Banner.Mode.OFF);
            application.setLogStartupInfo(false);
            application.setWebApplicationType(WebApplicationType.NONE);
            context = application.run();
        } catch (Throwable t) {
            context = null;
        }
        assertNotNull(context, "Spring application could not start. Check annotations and bean wiring.");
        return context;
    }

    private void closeContext(ConfigurableApplicationContext context) {
        if (context != null) {
            try {
                context.close();
            } catch (Throwable ignored) {
                // nothing to do
            }
        }
    }

    private Object requireBean(ConfigurableApplicationContext context, String className) {
        Class<?> type = requireClass(className);
        Object bean = null;
        try {
            bean = context.getBean(type);
        } catch (Throwable t) {
            bean = null;
        }
        assertNotNull(bean, "No Spring bean found for " + type.getSimpleName());
        return bean;
    }

    private Object call(Object target, String methodName, Object... args) throws Exception {
        assertNotNull(target, "Cannot call " + methodName + " on null");
        for (Method method : target.getClass().getMethods()) {
            if (method.getName().equals(methodName) && method.getParameterCount() == args.length) {
                try {
                    return method.invoke(target, args);
                } catch (IllegalArgumentException e) {
                    continue;
                } catch (InvocationTargetException e) {
                    throw new Exception(methodName + " threw " + e.getCause(), e.getCause());
                }
            }
        }
        throw new NoSuchMethodException("Method not found: " + methodName + " with " + args.length + " parameter(s)");
    }

    private Object create(String className, Object... args) throws Exception {
        Class<?> type = requireClass(className);
        for (Constructor<?> constructor : type.getConstructors()) {
            if (constructor.getParameterCount() == args.length) {
                try {
                    return constructor.newInstance(args);
                } catch (IllegalArgumentException e) {
                    continue;
                } catch (InvocationTargetException e) {
                    throw new Exception(type.getSimpleName() + " constructor threw " + e.getCause(), e.getCause());
                }
            }
        }
        throw new NoSuchMethodException("No public constructor with " + args.length + " parameter(s) in " + type.getSimpleName());
    }

    private void requireConstructor(Class<?> type, Class<?>... parameterTypes) {
        try {
            type.getConstructor(parameterTypes);
        } catch (Throwable t) {
            fail(type.getSimpleName() + " must have a public constructor with parameters " + Arrays.toString(parameterTypes));
        }
    }

    private void requireMethod(Class<?> type, String methodName, Class<?>... parameterTypes) {
        try {
            type.getMethod(methodName, parameterTypes);
        } catch (Throwable t) {
            fail(type.getSimpleName() + " must have a public method " + methodName + " with parameters " + Arrays.toString(parameterTypes));
        }
    }

    private int asInt(Object value) {
        assertTrue(value instanceof Number, "Expected a number but got " + value);
        return ((Number) value).intValue();
    }

    private List<?> asList(Object value) {
        assertNotNull(value, "Expected a List but got null");
        assertTrue(value instanceof List, "Expected a List but got " + value.getClass().getSimpleName());
        return (List<?>) value;
    }

    private List<String> values(Object list, String getterName) throws Exception {
        List<String> result = new ArrayList<>();
        for (Object item : asList(list)) {
            result.add(String.valueOf(call(item, getterName)));
        }
        return result;
    }

    private Object fieldOfType(Object target, Class<?> fieldType) throws Exception {
        for (Field field : target.getClass().getDeclaredFields()) {
            if (fieldType.isAssignableFrom(field.getType())) {
                field.setAccessible(true);
                return field.get(target);
            }
        }
        return null;
    }

    private void checkComponentBean(String className) {
        ConfigurableApplicationContext context = null;
        try {
            context = requireContext();
            Class<?> type = requireClass(className);
            String[] names = context.getBeanNamesForType(type);
            assertEquals(1, names.length, type.getSimpleName() + " must be registered once as a Spring bean");
            BeanDefinition definition = context.getBeanFactory().getBeanDefinition(names[0]);
            assertNull(definition.getFactoryMethodName(), type.getSimpleName() + " must be found by component scanning, not created by a @Bean method");
            assertSame(context.getBean(type), context.getBean(type), type.getSimpleName() + " must be a singleton");
        } catch (Exception e) {
            fail("Component check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    private void checkBeanMethod(String beanClassName, String methodName, String configClassName) {
        ConfigurableApplicationContext context = null;
        try {
            context = requireContext();
            Class<?> beanClass = requireClass(beanClassName);
            String[] names = context.getBeanNamesForType(beanClass);
            assertEquals(1, names.length, "Exactly one " + beanClass.getSimpleName() + " bean must exist");
            BeanDefinition definition = context.getBeanFactory().getBeanDefinition(names[0]);
            assertEquals(methodName, definition.getFactoryMethodName(), beanClass.getSimpleName() + " must be created by a @Bean method named " + methodName);
            assertNotNull(definition.getFactoryBeanName(), "The @Bean method must be inside a configuration class");
            Object configBean = context.getBean(definition.getFactoryBeanName());
            assertTrue(requireClass(configClassName).isInstance(configBean), "The @Bean method must be inside " + configClassName);
            assertSame(context.getBean(beanClass), call(configBean, methodName), "The configuration class must use @Configuration so the same bean is returned");
        } catch (Exception e) {
            fail("Configuration check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    private void checkPrintOutput(String serviceClassName, String loadMethod, String printMethod, String expected) {
        ConfigurableApplicationContext context = null;
        PrintStream originalOut = System.out;
        try {
            context = requireContext();
            Object service = requireBean(context, serviceClassName);
            call(service, loadMethod);
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            try {
                System.setOut(new PrintStream(buffer, true, "UTF-8"));
                call(service, printMethod);
            } finally {
                System.setOut(originalOut);
            }
            String actual = buffer.toString("UTF-8").replace("\r\n", "\n").replaceAll("\\n+$", "");
            assertEquals(expected, actual, "Terminal output does not match the expected output");
        } catch (Exception e) {
            System.setOut(originalOut);
            fail("Output check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    // ---------------- Test cases ----------------

    @Test
    public void testCompanyInfoBeanHasCorrectName() {
        ConfigurableApplicationContext context = null;
        try {
            context = requireContext();
            Object info = requireBean(context, INFO);
            assertEquals("TechNova Solutions", call(info, "getCompanyName"), "Company name is incorrect");
        } catch (Exception e) {
            fail("CompanyInfo bean check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    @Test
    public void testCompanyInfoCreatedByBeanMethodInConfiguration() {
        checkBeanMethod(INFO, "companyInfo", CONFIG);
    }

    @Test
    public void testEmployeeDirectoryIsComponentBean() {
        checkComponentBean(STORE);
    }

    @Test
    public void testDirectoryServiceIsComponentBean() {
        checkComponentBean(SERVICE);
    }

    @Test
    public void testDirectoryServiceUsesConstructorInjection() {
        ConfigurableApplicationContext context = null;
        try {
            Class<?> serviceClass = requireClass(SERVICE);
            requireConstructor(serviceClass, requireClass(STORE), requireClass(INFO));
            context = requireContext();
            Object service = requireBean(context, SERVICE);
            assertSame(requireBean(context, STORE), fieldOfType(service, requireClass(STORE)), "DirectoryService must receive the EmployeeDirectory bean from Spring");
            assertSame(requireBean(context, INFO), fieldOfType(service, requireClass(INFO)), "DirectoryService must receive the CompanyInfo bean from Spring");
        } catch (Exception e) {
            fail("Constructor injection check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    @Test
    public void testAddEmployeeStoresEmployeesById() {
        try {
            Object directory = create(STORE);
            assertEquals(Boolean.TRUE, call(directory, "addEmployee", create(EMPLOYEE, 201, "Divya", "HR")), "A new employee must be accepted");
            assertEquals(Boolean.TRUE, call(directory, "addEmployee", create(EMPLOYEE, 202, "Elango", "Sales")), "A new employee must be accepted");
            assertEquals(2, asInt(call(directory, "getEmployeeCount")), "Employee count is incorrect");
            assertEquals(Arrays.asList("201", "202"), values(call(directory, "getAllEmployees"), "getId"), "Employees must be kept in the order they were added");
            assertEquals("Elango", call(call(directory, "findEmployee", 202), "getName"), "findEmployee returned the wrong employee");
        } catch (Exception e) {
            fail("Add employee check failed: " + e);
        }
    }

    @Test
    public void testAddEmployeeRejectsDuplicateIdAndNull() {
        try {
            Object directory = create(STORE);
            call(directory, "addEmployee", create(EMPLOYEE, 201, "Divya", "HR"));
            assertEquals(Boolean.FALSE, call(directory, "addEmployee", create(EMPLOYEE, 201, "Someone", "Sales")), "A duplicate id must be rejected");
            assertEquals(Boolean.FALSE, call(directory, "addEmployee", new Object[] {null}), "A null employee must be rejected");
            assertEquals(1, asInt(call(directory, "getEmployeeCount")), "Rejected employees must not be stored");
            assertEquals("Divya", call(call(directory, "findEmployee", 201), "getName"), "The original employee must not be replaced");
        } catch (Exception e) {
            fail("Duplicate employee check failed: " + e);
        }
    }

    @Test
    public void testGetEmployeesByDepartmentFiltersCorrectly() {
        try {
            Object directory = create(STORE);
            call(directory, "addEmployee", create(EMPLOYEE, 301, "Farah", "Testing"));
            call(directory, "addEmployee", create(EMPLOYEE, 302, "Gokul", "Development"));
            call(directory, "addEmployee", create(EMPLOYEE, 303, "Hema", "Testing"));
            assertEquals(Arrays.asList("Farah", "Hema"), values(call(directory, "getEmployeesByDepartment", "Testing"), "getName"), "Department filter is incorrect");
            assertTrue(asList(call(directory, "getEmployeesByDepartment", "Finance")).isEmpty(), "An unknown department must give an empty list");
            assertNull(call(directory, "findEmployee", 999), "findEmployee must return null for an unknown id");
        } catch (Exception e) {
            fail("Department filter check failed: " + e);
        }
    }

    @Test
    public void testLoadEmployeesAddsThreeEmployees() {
        ConfigurableApplicationContext context = null;
        try {
            context = requireContext();
            Object service = requireBean(context, SERVICE);
            Object directory = requireBean(context, STORE);
            call(service, "loadEmployees");
            assertEquals(3, asInt(call(directory, "getEmployeeCount")), "loadEmployees must add 3 employees");
            assertEquals(Arrays.asList("Anitha", "Bharath", "Charan"), values(call(directory, "getAllEmployees"), "getName"), "Employees loaded are incorrect or in the wrong order");
            assertEquals("Testing", call(call(directory, "findEmployee", 102), "getDepartment"), "Employee 102 has the wrong department");
        } catch (Exception e) {
            fail("Load employees check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    @Test
    public void testPrintDirectoryShowsExactOutput() {
        checkPrintOutput(SERVICE, "loadEmployees", "printDirectory", EXPECTED_OUTPUT);
    }
}
