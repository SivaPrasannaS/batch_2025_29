package com.examly.springapp.service;

public class EmployeeDirectory {

}
