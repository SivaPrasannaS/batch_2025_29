package com.examly.springapp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.context.ConfigurableApplicationContext;

public class StudentMarksAssessmentTests {

    private static final String BASE = "com.examly.springapp";
    private static final String MAIN_CLASS = BASE + ".SpringappApplication";
    private static final String STUDENT = BASE + ".model.Student";
    private static final String INFO = BASE + ".model.ClassInfo";
    private static final String CONFIG = BASE + ".config.ClassConfig";
    private static final String STORE = BASE + ".service.StudentRegister";
    private static final String SERVICE = BASE + ".service.ResultService";

    private static final String EXPECTED_OUTPUT = String.join("\n",
            "Class: CSE-A",
            "Pass mark: 40",
            "Arun - 78 - PASS",
            "Bala - 35 - FAIL",
            "Chitra - 62 - PASS",
            "Divya - 40 - PASS",
            "Passed students: 3");

    // ---------------- Helper methods ----------------
    // Student classes are used only through reflection, so this file
    // always compiles even if a class or method is missing.

    private Class<?> requireClass(String className) {
        Class<?> type = null;
        try {
            type = Class.forName(className);
        } catch (Throwable t) {
            type = null;
        }
        assertNotNull(type, "Class not found: " + className);
        return type;
    }

    private ConfigurableApplicationContext requireContext() {
        ConfigurableApplicationContext context = null;
        try {
            SpringApplication application = new SpringApplication(Class.forName(MAIN_CLASS));
            application.setBannerMode(Banner.Mode.OFF);
            application.setLogStartupInfo(false);
            application.setWebApplicationType(WebApplicationType.NONE);
            context = application.run();
        } catch (Throwable t) {
            context = null;
        }
        assertNotNull(context, "Spring application could not start. Check annotations and bean wiring.");
        return context;
    }

    private void closeContext(ConfigurableApplicationContext context) {
        if (context != null) {
            try {
                context.close();
            } catch (Throwable ignored) {
                // nothing to do
            }
        }
    }

    private Object requireBean(ConfigurableApplicationContext context, String className) {
        Class<?> type = requireClass(className);
        Object bean = null;
        try {
            bean = context.getBean(type);
        } catch (Throwable t) {
            bean = null;
        }
        assertNotNull(bean, "No Spring bean found for " + type.getSimpleName());
        return bean;
    }

    private Object call(Object target, String methodName, Object... args) throws Exception {
        assertNotNull(target, "Cannot call " + methodName + " on null");
        for (Method method : target.getClass().getMethods()) {
            if (method.getName().equals(methodName) && method.getParameterCount() == args.length) {
                try {
                    return method.invoke(target, args);
                } catch (IllegalArgumentException e) {
                    continue;
                } catch (InvocationTargetException e) {
                    throw new Exception(methodName + " threw " + e.getCause(), e.getCause());
                }
            }
        }
        throw new NoSuchMethodException("Method not found: " + methodName + " with " + args.length + " parameter(s)");
    }

    private Object create(String className, Object... args) throws Exception {
        Class<?> type = requireClass(className);
        for (Constructor<?> constructor : type.getConstructors()) {
            if (constructor.getParameterCount() == args.length) {
                try {
                    return constructor.newInstance(args);
                } catch (IllegalArgumentException e) {
                    continue;
                } catch (InvocationTargetException e) {
                    throw new Exception(type.getSimpleName() + " constructor threw " + e.getCause(), e.getCause());
                }
            }
        }
        throw new NoSuchMethodException("No public constructor with " + args.length + " parameter(s) in " + type.getSimpleName());
    }

    private void requireConstructor(Class<?> type, Class<?>... parameterTypes) {
        try {
            type.getConstructor(parameterTypes);
        } catch (Throwable t) {
            fail(type.getSimpleName() + " must have a public constructor with parameters " + Arrays.toString(parameterTypes));
        }
    }

    private void requireMethod(Class<?> type, String methodName, Class<?>... parameterTypes) {
        try {
            type.getMethod(methodName, parameterTypes);
        } catch (Throwable t) {
            fail(type.getSimpleName() + " must have a public method " + methodName + " with parameters " + Arrays.toString(parameterTypes));
        }
    }

    private int asInt(Object value) {
        assertTrue(value instanceof Number, "Expected a number but got " + value);
        return ((Number) value).intValue();
    }

    private List<?> asList(Object value) {
        assertNotNull(value, "Expected a List but got null");
        assertTrue(value instanceof List, "Expected a List but got " + value.getClass().getSimpleName());
        return (List<?>) value;
    }

    private List<String> values(Object list, String getterName) throws Exception {
        List<String> result = new ArrayList<>();
        for (Object item : asList(list)) {
            result.add(String.valueOf(call(item, getterName)));
        }
        return result;
    }

    private Object fieldOfType(Object target, Class<?> fieldType) throws Exception {
        for (Field field : target.getClass().getDeclaredFields()) {
            if (fieldType.isAssignableFrom(field.getType())) {
                field.setAccessible(true);
                return field.get(target);
            }
        }
        return null;
    }

    private void checkComponentBean(String className) {
        ConfigurableApplicationContext context = null;
        try {
            context = requireContext();
            Class<?> type = requireClass(className);
            String[] names = context.getBeanNamesForType(type);
            assertEquals(1, names.length, type.getSimpleName() + " must be registered once as a Spring bean");
            BeanDefinition definition = context.getBeanFactory().getBeanDefinition(names[0]);
            assertNull(definition.getFactoryMethodName(), type.getSimpleName() + " must be found by component scanning, not created by a @Bean method");
            assertSame(context.getBean(type), context.getBean(type), type.getSimpleName() + " must be a singleton");
        } catch (Exception e) {
            fail("Component check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    private void checkBeanMethod(String beanClassName, String methodName, String configClassName) {
        ConfigurableApplicationContext context = null;
        try {
            context = requireContext();
            Class<?> beanClass = requireClass(beanClassName);
            String[] names = context.getBeanNamesForType(beanClass);
            assertEquals(1, names.length, "Exactly one " + beanClass.getSimpleName() + " bean must exist");
            BeanDefinition definition = context.getBeanFactory().getBeanDefinition(names[0]);
            assertEquals(methodName, definition.getFactoryMethodName(), beanClass.getSimpleName() + " must be created by a @Bean method named " + methodName);
            assertNotNull(definition.getFactoryBeanName(), "The @Bean method must be inside a configuration class");
            Object configBean = context.getBean(definition.getFactoryBeanName());
            assertTrue(requireClass(configClassName).isInstance(configBean), "The @Bean method must be inside " + configClassName);
            assertSame(context.getBean(beanClass), call(configBean, methodName), "The configuration class must use @Configuration so the same bean is returned");
        } catch (Exception e) {
            fail("Configuration check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    private void checkPrintOutput(String serviceClassName, String loadMethod, String printMethod, String expected) {
        ConfigurableApplicationContext context = null;
        PrintStream originalOut = System.out;
        try {
            context = requireContext();
            Object service = requireBean(context, serviceClassName);
            call(service, loadMethod);
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            try {
                System.setOut(new PrintStream(buffer, true, "UTF-8"));
                call(service, printMethod);
            } finally {
                System.setOut(originalOut);
            }
            String actual = buffer.toString("UTF-8").replace("\r\n", "\n").replaceAll("\\n+$", "");
            assertEquals(expected, actual, "Terminal output does not match the expected output");
        } catch (Exception e) {
            System.setOut(originalOut);
            fail("Output check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    // ---------------- Test cases ----------------

    @Test
    public void testClassInfoBeanHasCorrectValues() {
        ConfigurableApplicationContext context = null;
        try {
            context = requireContext();
            Object info = requireBean(context, INFO);
            assertEquals("CSE-A", call(info, "getClassName"), "Class name is incorrect");
            assertEquals(40, asInt(call(info, "getPassMark")), "Pass mark is incorrect");
        } catch (Exception e) {
            fail("ClassInfo bean check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    @Test
    public void testClassInfoCreatedByBeanMethodInConfiguration() {
        checkBeanMethod(INFO, "classInfo", CONFIG);
    }

    @Test
    public void testStudentRegisterIsComponentBean() {
        checkComponentBean(STORE);
    }

    @Test
    public void testResultServiceIsComponentBean() {
        checkComponentBean(SERVICE);
    }

    @Test
    public void testResultServiceUsesConstructorInjection() {
        ConfigurableApplicationContext context = null;
        try {
            Class<?> serviceClass = requireClass(SERVICE);
            requireConstructor(serviceClass, requireClass(STORE), requireClass(INFO));
            context = requireContext();
            Object service = requireBean(context, SERVICE);
            assertSame(requireBean(context, STORE), fieldOfType(service, requireClass(STORE)), "ResultService must receive the StudentRegister bean from Spring");
            assertSame(requireBean(context, INFO), fieldOfType(service, requireClass(INFO)), "ResultService must receive the ClassInfo bean from Spring");
        } catch (Exception e) {
            fail("Constructor injection check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    @Test
    public void testAddStudentStoresStudentsInList() {
        try {
            Object register = create(STORE);
            assertEquals(0, asInt(call(register, "getStudentCount")), "A new register must be empty");
            call(register, "addStudent", create(STUDENT, "Kavin", 88));
            call(register, "addStudent", create(STUDENT, "Latha", 52));
            assertEquals(2, asInt(call(register, "getStudentCount")), "Student count is incorrect");
            assertEquals(Arrays.asList("Kavin", "Latha"), values(call(register, "getAllStudents"), "getName"), "Students must be kept in the order they were added");
        } catch (Exception e) {
            fail("Add student check failed: " + e);
        }
    }

    @Test
    public void testAddStudentIgnoresNullStudent() {
        try {
            Object register = create(STORE);
            call(register, "addStudent", create(STUDENT, "Kavin", 88));
            call(register, "addStudent", new Object[] {null});
            assertEquals(1, asInt(call(register, "getStudentCount")), "A null student must not be added");
        } catch (Exception e) {
            fail("Null student check failed: " + e);
        }
    }

    @Test
    public void testGetPassedStudentsFiltersByPassMark() {
        try {
            Object register = create(STORE);
            call(register, "addStudent", create(STUDENT, "Arun", 78));
            call(register, "addStudent", create(STUDENT, "Bala", 35));
            call(register, "addStudent", create(STUDENT, "Chitra", 62));
            call(register, "addStudent", create(STUDENT, "Divya", 40));
            assertEquals(Arrays.asList("Arun", "Chitra"), values(call(register, "getPassedStudents", 50), "getName"), "Filtering with pass mark 50 is incorrect");
            assertEquals(Arrays.asList("Arun", "Chitra", "Divya"), values(call(register, "getPassedStudents", 40), "getName"), "Marks equal to the pass mark must count as pass");
            assertEquals(4, asInt(call(register, "getStudentCount")), "Filtering must not remove students");
        } catch (Exception e) {
            fail("Passed students check failed: " + e);
        }
    }

    @Test
    public void testLoadStudentsAddsFourStudents() {
        ConfigurableApplicationContext context = null;
        try {
            context = requireContext();
            Object service = requireBean(context, SERVICE);
            Object register = requireBean(context, STORE);
            call(service, "loadStudents");
            assertEquals(4, asInt(call(register, "getStudentCount")), "loadStudents must add 4 students");
            assertEquals(Arrays.asList("Arun", "Bala", "Chitra", "Divya"), values(call(register, "getAllStudents"), "getName"), "Students loaded are incorrect or in the wrong order");
            assertEquals(Arrays.asList("78", "35", "62", "40"), values(call(register, "getAllStudents"), "getMarks"), "Student marks are incorrect");
        } catch (Exception e) {
            fail("Load students check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    @Test
    public void testPrintResultsShowsExactOutput() {
        checkPrintOutput(SERVICE, "loadStudents", "printResults", EXPECTED_OUTPUT);
    }
}
