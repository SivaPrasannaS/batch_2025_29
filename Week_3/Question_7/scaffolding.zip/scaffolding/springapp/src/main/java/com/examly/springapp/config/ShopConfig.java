package com.examly.springapp.config;

public class ShopConfig {

}
