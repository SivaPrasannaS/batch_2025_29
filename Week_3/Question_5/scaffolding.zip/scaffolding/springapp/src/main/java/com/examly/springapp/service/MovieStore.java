package com.examly.springapp.service;

public class MovieStore {

}
