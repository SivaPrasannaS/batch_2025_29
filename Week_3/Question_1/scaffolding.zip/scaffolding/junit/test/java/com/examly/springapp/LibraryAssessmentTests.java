package com.examly.springapp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.context.ConfigurableApplicationContext;

public class LibraryAssessmentTests {

    private static final String BASE = "com.examly.springapp";
    private static final String MAIN_CLASS = BASE + ".SpringappApplication";
    private static final String BOOK_CLASS = BASE + ".model.Book";
    private static final String INFO_CLASS = BASE + ".model.LibraryInfo";
    private static final String CONFIG_CLASS = BASE + ".config.LibraryConfig";
    private static final String STORE_CLASS = BASE + ".service.BookStore";
    private static final String SERVICE_CLASS = BASE + ".service.LibraryService";

    private static final String EXPECTED_OUTPUT = String.join("\n",
            "Welcome to City College Library",
            "Total books: 3",
            "B101 - Clean Code",
            "B102 - Head First Java",
            "B103 - Effective Java");

    // ---------------- Helper methods ----------------
    // Student classes are used only through reflection, so this file
    // always compiles even if a class or method is missing.

    private Class<?> requireClass(String className) {
        Class<?> type = null;
        try {
            type = Class.forName(className);
        } catch (Throwable t) {
            type = null;
        }
        assertNotNull(type, "Class not found: " + className);
        return type;
    }

    private ConfigurableApplicationContext requireContext() {
        ConfigurableApplicationContext context = null;
        try {
            SpringApplication application = new SpringApplication(Class.forName(MAIN_CLASS));
            application.setBannerMode(Banner.Mode.OFF);
            application.setLogStartupInfo(false);
            application.setWebApplicationType(WebApplicationType.NONE);
            context = application.run();
        } catch (Throwable t) {
            context = null;
        }
        assertNotNull(context, "Spring application could not start. Check annotations and bean wiring.");
        return context;
    }

    private void closeContext(ConfigurableApplicationContext context) {
        if (context != null) {
            try {
                context.close();
            } catch (Throwable ignored) {
                // nothing to do
            }
        }
    }

    private Object requireBean(ConfigurableApplicationContext context, String className) {
        Class<?> type = requireClass(className);
        Object bean = null;
        try {
            bean = context.getBean(type);
        } catch (Throwable t) {
            bean = null;
        }
        assertNotNull(bean, "No Spring bean found for " + type.getSimpleName());
        return bean;
    }

    private Object call(Object target, String methodName, Object... args) throws Exception {
        assertNotNull(target, "Cannot call " + methodName + " on null");
        for (Method method : target.getClass().getMethods()) {
            if (method.getName().equals(methodName) && method.getParameterCount() == args.length) {
                try {
                    return method.invoke(target, args);
                } catch (InvocationTargetException e) {
                    throw new Exception(methodName + " threw " + e.getCause(), e.getCause());
                }
            }
        }
        throw new NoSuchMethodException("Method not found: " + methodName);
    }

    private Object newBook(String bookId, String title) throws Exception {
        return requireClass(BOOK_CLASS).getConstructor(String.class, String.class).newInstance(bookId, title);
    }

    private Object newBookStore() throws Exception {
        return requireClass(STORE_CLASS).getConstructor().newInstance();
    }

    private int asInt(Object value) {
        assertTrue(value instanceof Number, "Expected a number but got " + value);
        return ((Number) value).intValue();
    }

    private List<String> bookIds(Object books) throws Exception {
        assertTrue(books instanceof List, "getAllBooks must return a List");
        List<String> ids = new ArrayList<>();
        for (Object book : (List<?>) books) {
            ids.add(String.valueOf(call(book, "getBookId")));
        }
        return ids;
    }

    private Object fieldOfType(Object target, Class<?> fieldType) throws Exception {
        for (Field field : target.getClass().getDeclaredFields()) {
            if (fieldType.isAssignableFrom(field.getType())) {
                field.setAccessible(true);
                return field.get(target);
            }
        }
        return null;
    }

    private void checkComponentBean(String className) {
        ConfigurableApplicationContext context = null;
        try {
            context = requireContext();
            Class<?> type = requireClass(className);
            String[] names = context.getBeanNamesForType(type);
            assertEquals(1, names.length, type.getSimpleName() + " must be registered once as a Spring bean");
            BeanDefinition definition = context.getBeanFactory().getBeanDefinition(names[0]);
            assertNull(definition.getFactoryMethodName(), type.getSimpleName() + " must be found by component scanning, not created by a @Bean method");
            assertSame(context.getBean(type), context.getBean(type), type.getSimpleName() + " must be a singleton");
        } catch (Exception e) {
            fail("Component check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    // ---------------- Test cases ----------------

    @Test
    public void testLibraryInfoBeanHasCorrectName() {
        ConfigurableApplicationContext context = null;
        try {
            context = requireContext();
            Object info = requireBean(context, INFO_CLASS);
            assertEquals("City College Library", call(info, "getLibraryName"), "Library name is incorrect");
        } catch (Exception e) {
            fail("LibraryInfo bean check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    @Test
    public void testLibraryInfoCreatedByBeanMethodInConfiguration() {
        ConfigurableApplicationContext context = null;
        try {
            context = requireContext();
            Class<?> infoClass = requireClass(INFO_CLASS);
            String[] names = context.getBeanNamesForType(infoClass);
            assertEquals(1, names.length, "Exactly one LibraryInfo bean must exist");

            BeanDefinition definition = context.getBeanFactory().getBeanDefinition(names[0]);
            assertEquals("libraryInfo", definition.getFactoryMethodName(), "LibraryInfo must be created by a @Bean method named libraryInfo");
            assertNotNull(definition.getFactoryBeanName(), "The @Bean method must be inside a configuration class");

            Object configBean = context.getBean(definition.getFactoryBeanName());
            assertTrue(requireClass(CONFIG_CLASS).isInstance(configBean), "The @Bean method must be inside LibraryConfig");
            assertSame(context.getBean(infoClass), call(configBean, "libraryInfo"), "LibraryConfig must be a @Configuration class so the same bean is returned");
        } catch (Exception e) {
            fail("Configuration check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    @Test
    public void testBookStoreIsComponentBean() {
        checkComponentBean(STORE_CLASS);
    }

    @Test
    public void testLibraryServiceIsComponentBean() {
        checkComponentBean(SERVICE_CLASS);
    }

    @Test
    public void testLibraryServiceReceivesInjectedBeans() {
        ConfigurableApplicationContext context = null;
        try {
            context = requireContext();
            Object store = requireBean(context, STORE_CLASS);
            Object info = requireBean(context, INFO_CLASS);
            Object service = requireBean(context, SERVICE_CLASS);
            assertSame(store, fieldOfType(service, requireClass(STORE_CLASS)), "LibraryService must receive the BookStore bean from Spring");
            assertSame(info, fieldOfType(service, requireClass(INFO_CLASS)), "LibraryService must receive the LibraryInfo bean from Spring");
        } catch (Exception e) {
            fail("Injection check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    @Test
    public void testAddBookStoresBooksInList() {
        try {
            Object store = newBookStore();
            assertEquals(0, asInt(call(store, "getBookCount")), "A new BookStore must be empty");
            call(store, "addBook", newBook("B201", "Java Basics"));
            call(store, "addBook", newBook("B202", "Spring Basics"));
            assertEquals(2, asInt(call(store, "getBookCount")), "Book count is incorrect");
            assertEquals(Arrays.asList("B201", "B202"), bookIds(call(store, "getAllBooks")), "Books must be kept in the order they were added");
        } catch (Exception e) {
            fail("Add book check failed: " + e);
        }
    }

    @Test
    public void testAddBookIgnoresNullBook() {
        try {
            Object store = newBookStore();
            call(store, "addBook", newBook("B201", "Java Basics"));
            call(store, "addBook", new Object[] {null});
            assertEquals(1, asInt(call(store, "getBookCount")), "A null book must not be added");
            assertEquals(Arrays.asList("B201"), bookIds(call(store, "getAllBooks")), "The list must contain only real books");
        } catch (Exception e) {
            fail("Null book check failed: " + e);
        }
    }

    @Test
    public void testFindBookByIdReturnsCorrectBook() {
        try {
            Object store = newBookStore();
            call(store, "addBook", newBook("B201", "Java Basics"));
            call(store, "addBook", newBook("B202", "Spring Basics"));
            Object found = call(store, "findBookById", "B202");
            assertNotNull(found, "findBookById must return the matching book");
            assertEquals("Spring Basics", call(found, "getTitle"), "findBookById returned the wrong book");
            assertNull(call(store, "findBookById", "B999"), "findBookById must return null for an unknown id");
        } catch (Exception e) {
            fail("Find book check failed: " + e);
        }
    }

    @Test
    public void testLoadBooksAddsThreeBooksToBookStore() {
        ConfigurableApplicationContext context = null;
        try {
            context = requireContext();
            Object service = requireBean(context, SERVICE_CLASS);
            Object store = requireBean(context, STORE_CLASS);
            call(service, "loadBooks");
            assertEquals(3, asInt(call(store, "getBookCount")), "loadBooks must add 3 books");
            assertEquals(Arrays.asList("B101", "B102", "B103"), bookIds(call(store, "getAllBooks")), "Books loaded are incorrect or in the wrong order");
            assertEquals("Head First Java", call(call(store, "findBookById", "B102"), "getTitle"), "Book B102 has the wrong title");
        } catch (Exception e) {
            fail("Load books check failed: " + e);
        } finally {
            closeContext(context);
        }
    }

    @Test
    public void testPrintBooksShowsExactOutput() {
        ConfigurableApplicationContext context = null;
        PrintStream originalOut = System.out;
        try {
            context = requireContext();
            Object service = requireBean(context, SERVICE_CLASS);
            call(service, "loadBooks");

            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            try {
                System.setOut(new PrintStream(buffer, true, "UTF-8"));
                call(service, "printBooks");
            } finally {
                System.setOut(originalOut);
            }
            String actual = buffer.toString("UTF-8").replace("\r\n", "\n").replaceAll("\\n+$", "");
            assertEquals(EXPECTED_OUTPUT, actual, "Terminal output does not match the expected output");
        } catch (Exception e) {
            System.setOut(originalOut);
            fail("Print books check failed: " + e);
        } finally {
            closeContext(context);
        }
    }
}
